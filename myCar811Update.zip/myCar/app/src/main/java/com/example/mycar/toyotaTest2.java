package com.example.mycar;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class toyotaTest2 extends AppCompatActivity {
private Button checkInput2;
private Button text1;
EditText editText1;
    int score;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
String answer="toyota";





        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_toyota_test2);

        editText1= (EditText)findViewById(R.id.input1);



        Button button=(Button)findViewById(R.id.checkInput2);
        button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View checkInput2)

            {

                if(editText1.getText().toString().equals("test")){


                    Toast.makeText(toyotaTest2.this,"welcome boss" , Toast.LENGTH_SHORT).show();

                startActivity(new Intent(toyotaTest2.this, toyotaTest.class));
                }

            else{


                    Button btnOver = (Button)findViewById(R.id.checkInput2);

                    btnOver.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            startActivity(new Intent(toyotaTest2.this, gameOver.class));
                        }
                    });

           /* if you want to finish the first activity then just call input1
            finish(); */
                }

                    }


           /* if you want to finish the first activity then just call input1
            finish(); */

        });


    }
}