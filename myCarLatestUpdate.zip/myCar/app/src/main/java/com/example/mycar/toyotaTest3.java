package com.example.mycar;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class toyotaTest3 extends AppCompatActivity {
    EditText editText3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
toyotaTest callToyotaTest=new toyotaTest();

        editText3=(EditText)findViewById(R.id.input3);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_toyota_test3);
        Button btn = (Button)findViewById(R.id.checkInput3);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(toyotaTest3.this, congrats.class));

            }
        });
    }
}