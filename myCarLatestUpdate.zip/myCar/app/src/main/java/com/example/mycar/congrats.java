package com.example.mycar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class congrats extends AppCompatActivity {
toyotaTest2 callToyotaTest2=new toyotaTest2();
    toyotaTest callToyotaTest=new toyotaTest();
    @Override
    protected void onCreate(Bundle savedInstanceState) {


        getSupportActionBar().hide();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_congrats);

        TextView theTextView=(TextView) findViewById(R.id.scoreMessageID);
         theTextView.setText("Your score: ");
    }
}