package com.example.mycar;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class loginNew extends AppCompatActivity {
    Button butonLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        butonLogin=findViewById(R.id.loginButtonTest);


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_new);

        Button btn = (Button)findViewById(R.id.loginButtonTest);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(loginNew.this, "LOGIN SUCCESSFUL", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(loginNew.this, homePage.class));
            }
        });
    }


}