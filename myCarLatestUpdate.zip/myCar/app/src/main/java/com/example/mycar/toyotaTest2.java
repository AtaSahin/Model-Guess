package com.example.mycar;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class toyotaTest2 extends AppCompatActivity {
private Button checkInput2;
private Button text1;
EditText editText1;
EditText editText2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        new CountDownTimer(30000, 1000) {

            public void onTick(long millisUntilFinished) {
                editText2.setText("\t\t\t" + millisUntilFinished / 1000);
            }

            public void onFinish() {
                Toast.makeText(toyotaTest2.this, "Time is up!", Toast.LENGTH_SHORT).show();
                editText2.setText("\t\t\t:(");
                new Handler().postDelayed(() -> {
                    startActivity(new Intent(toyotaTest2.this,gameOver.class));
                    finish();
                }, 2000);
            }
        }.start();


        getSupportActionBar().hide();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_toyota_test2);

        editText1= (EditText)findViewById(R.id.input1);
        editText2= (EditText)findViewById(R.id.input12);



        Button button=(Button)findViewById(R.id.checkInput2);

        button.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View checkInput2)

            {


                if(editText1.getText().toString().equals("test")){




                    Toast.makeText(toyotaTest2.this,"Correct Answer" , Toast.LENGTH_SHORT).show();

                    startActivity(new Intent(toyotaTest2.this, toyotaTest.class));



                }

                else{


                        Toast.makeText(toyotaTest2.this, "Wrong Answer! ", Toast.LENGTH_SHORT).show();





                    Button btnOver = (Button)findViewById(R.id.checkInput2);

                    btnOver.setOnClickListener(new View.OnClickListener() {

                        @Override

                        public void onClick(View v) {
                            startActivity(new Intent(toyotaTest2.this, gameOver.class));
                        }


                    });


                        Toast.makeText(toyotaTest2.this, "Game Over...", Toast.LENGTH_SHORT).show();

                        }

                    }


           /* if you want to finish the first activity then just call input1
            finish(); */






           /* if you want to finish the first activity then just call input1
            finish(); */

            });


        }


}
