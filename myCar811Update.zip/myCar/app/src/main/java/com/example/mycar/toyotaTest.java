package com.example.mycar;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class toyotaTest extends AppCompatActivity {
    int count= 3;
    EditText editText2;



    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_toyota_test);
        editText2= (EditText)findViewById(R.id.input2);

        Button btn = (Button)findViewById(R.id.checkToyota1Input);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(editText2.getText().toString().equals("testiki")){
                startActivity(new Intent(toyotaTest.this, toyotaTest3.class));

                }

                else{

                    Toast.makeText(toyotaTest.this, "Try Again", Toast.LENGTH_SHORT).show();

                    }
                    Button btnOver = (Button)findViewById(R.id.checkInput2);

                    btnOver.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                        }
                    });
                }

        });








    }
}